﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletControl1 : MonoBehaviour
{
    public float speed = 20;
    

    void Sart()
    {
        //gameObject.GetComponent<Collider2D>().isTrigger = false;
    }

	void Update ()
    {
        GetComponent<Rigidbody2D>().velocity = new Vector2(speed, GetComponent<Rigidbody2D>().velocity.y); 	
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Player1" || other.tag == "Player2")
        {
            Destroy(other.gameObject);
            //gameObject.GetComponent<Collider2D>().isTrigger = false;
        }

        else if(other.tag == "Border")
        {
            
        }
    }
}
