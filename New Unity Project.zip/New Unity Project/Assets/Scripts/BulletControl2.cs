﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletControl2 : MonoBehaviour
{
    public float speed = 20;
    public GameObject Bullet2;
    public GameObject Border;

    void Start()
    {
        Bullet2.GetComponent<Player_2_Movement>();
    }

	void Update ()
    {
        GetComponent<Rigidbody2D>().velocity = new Vector2(speed *(-1), GetComponent<Rigidbody2D>().velocity.y);
        Physics2D.IgnoreCollision(Bullet2.GetComponent<Collider2D>(), Border.GetComponent<Collider2D>());
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Player1" || other.tag == "Player2")
        {
            Destroy(other.gameObject);
        }

        Destroy(gameObject);
    }
}
