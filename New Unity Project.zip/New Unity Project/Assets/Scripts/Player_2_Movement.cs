﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_2_Movement : MonoBehaviour
{
    private Rigidbody2D Rig2D;
    public float Speed;

    public Transform GunEnd;
    public GameObject Bullet2;

    public KeyCode up;
    public KeyCode down;
    public KeyCode left;
    public KeyCode right;

    void Start()
    {
        Rig2D = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        if (Input.GetKey(up))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(moveVertical, 0);
            //Rig2D.AddForce(GetComponent<Rigidbody2D>().velocity * Speed);
        }

        if (Input.GetKey(down))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(moveVertical *(-1), 0);
            //Rig2D.AddForce(GetComponent<Rigidbody2D>().velocity * Speed);
        }

        if (Input.GetKey(right))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(moveHorizontal, 0);
            //Rig2D.AddForce(GetComponent<Rigidbody2D>().velocity * Speed);
        }

        if (Input.GetKey(left))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(moveHorizontal *(-1), 0);
            //Rig2D.AddForce(GetComponent<Rigidbody2D>().velocity * Speed);
        }



        //Vector2 movement = new Vector2(moveHorizontal, moveVertical);
        //Rig2D.AddForce(movement * Speed);


        if (Input.GetKeyDown(KeyCode.RightControl))
        {
            Instantiate(Bullet2, GunEnd.position, GunEnd.rotation);
        }
    }
}
