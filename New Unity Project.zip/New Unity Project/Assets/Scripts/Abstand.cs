﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Abstand : MonoBehaviour
{
    public GameObject Player1;
    public GameObject Player2;
    public float dist = 0;


    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        dist = Vector2.Distance(Player1.transform.position, Player2.transform.position);
    }
}
