﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Beginn : MonoBehaviour
{
    public GameObject Border;
    public Transform BorderSpawn;

    void Start()
    {
        Instantiate(Border, BorderSpawn.position, BorderSpawn.rotation);
    }
}