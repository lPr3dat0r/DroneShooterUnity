﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_1_Movement : MonoBehaviour
{
    private Rigidbody2D Rig2D;
    public float Speed;

    public Transform GunEnd;
    public GameObject Bullet1;

    void Start()
    {
        Rig2D = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        
        float moveHorizontal = Input.GetAxis ("Horizontal");
        float moveVertivcal = Input.GetAxis("Vertical");

        
            Vector2 movement = new Vector2(moveHorizontal, moveVertivcal);
            Rig2D.AddForce(movement * Speed);
       

        if(Input.GetKeyDown(KeyCode.LeftControl))
        {
            Instantiate(Bullet1, GunEnd.position, GunEnd.rotation);
        }
    }
}
